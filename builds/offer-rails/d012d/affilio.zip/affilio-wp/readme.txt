=== Affilio ===
Contributors: affilio
Stable tag: 0.1.17
License: GPLv2 or later

AI affiliate copilot for WordPress. Connect from Settings, then review recommendations before anything is inserted.

== Changelog ==

= 0.1.17 =
* The first Scan All after activation stays on the scan screen. The setup redirect no longer runs on admin-post.php.
* A sleeping host still says the service is starting. A wrong or refused API URL says to check the address in Impostazioni › Affilio.
* Connect errors follow the admin language, in Italian when that language is Italian.
* Scan All sends one batch per request. A post the host rejects is still skipped and reported.
* A 401 removal notice tells the owner to check the API key. Other 4xx notices name the code and leave out the English API reason. The command line still prints the code and the reason.

= 0.1.16 =
* A removal the service answers with 409 not_published stays removed locally and is not retried. The notice is "Rimosso dal post. L'inserimento non era pubblicato, quindi non c'è niente da segnalare."
* Any other 4xx is not queued. The notice names the HTTP code and the command exits 1. Only a network error or a 5xx is retried.

= 0.1.15 =
* An inserted placement ends with the plain text "(link sponsorizzato)" after the link. The link text is "Vedi il prodotto" with non-breaking spaces, in the same paragraph.
* Removing an insertion still finds that paragraph when the class was deleted, as long as the link is the tracked go URL or the placement id was named.
* Settings refuse an API URL override that is not https, unless the host is localhost or 127.0.0.1. The message is in Italian.

= 0.1.14 =
* A post counts as already disclosed only when it matches the receipt rule: the approved disclosure, "commissione", or "link" within 60 characters of "affiliat".
* If publication is refused, the insert is removed and the admin sees the reason in Italian. That automatic revert does not tell the service the placement was removed.
* An insert is a paragraph block marked with the class `affilio-placement-<placement id>`. A disclosure the plugin adds uses `affilio-disclosure-<placement id>`.
* Placement list: "Rimuovi inserimento" asks you to confirm the post and the exact link, then removes that block. The notice says whether the service was told.
* WP-CLI: `wp affilio revert <post_id> [--placement=<id>] [--dry-run]`. The post is edited first. The command prints the post change and the API result separately, and exits 0 when the local revert succeeded.

== Removing an insertion ==

From the placement list, "Rimuovi inserimento" shows the post title and the link (anchor text and go URL). Annulla leaves the post alone. Rimuovi edits the post, then reports the removal. If the service is unreachable, the post stays reverted and the report is retried.

From WP-CLI, when it is loaded:

`wp affilio revert 42`
`wp affilio revert 42 --placement=<placement id>`
`wp affilio revert 42 --dry-run`

`--dry-run` prints the post change and does not call the API. A local revert exits 0 even when the API result is "API: non raggiungibile, riprovo più tardi". Nothing matched locally exits non-zero.

= 0.1.13 =
* A placement receipt accepts a disclosure already written in the post. The setting does not skip Affilio's disclosure unless that post text actually discloses.

= 0.1.12 =
* Distribution matches listed offers that have no payment provider, and explains an empty result in Italian.
* An article keeps a single disclosure. A post that already discloses, or the setting "I miei articoli contengono già una disclosure", adds none.
* An approved recommendation is inserted as a Gutenberg paragraph with an Italian tracked link.
* Opportunities, prepare, and publish require a connected publisher account.
